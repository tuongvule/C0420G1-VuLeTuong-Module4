package com.codegym.cms.repository;

import com.codegym.cms.model.Role;

public interface RoleRepository extends Repository<Role> {
}
