package com.codegym.cms.repository;

import com.codegym.cms.model.Message;

public interface MessageRepository extends Repository<Message> {
}
